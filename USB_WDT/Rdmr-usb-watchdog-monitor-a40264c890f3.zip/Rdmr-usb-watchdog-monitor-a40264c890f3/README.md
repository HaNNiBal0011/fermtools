# README #

This is an App for USB WatchDog http://open-dev.ru/usb-watchdog/