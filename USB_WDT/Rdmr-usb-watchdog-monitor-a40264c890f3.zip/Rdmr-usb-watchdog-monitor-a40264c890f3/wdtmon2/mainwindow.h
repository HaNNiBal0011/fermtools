#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "QtSerialPort/QSerialPort"
#include "QtSerialPort/QSerialPortInfo"
#include<QTimer>
#include "serialthread.h"
#include <QSettings>
#include <QFile>
#include <QSystemTrayIcon>
#include <QLabel>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    QSerialPort *serialPort;
    QTimer *timer;
    QLabel *m_warningLabel;
    QSettings *main_settings;
    QSettings *win_settings;
    QString *ping_param;
    QString *ping_wait_param;


public slots:
    void scanPorts();
    void timer_int();
    void saveSettingsPort(QString);
    void saveSettingsTime(int);
    void saveSettingsPingTimeOut(int);
    void loadSettings(void);
    void timer_start(void);
    void ser_read(const QString &s);
    void ser_error(const QString &s);
    void reset_ch3(void);
    void reset_ch4(void);
    void power_ch3(void);
    void power_ch4(void);
    void set1_ch3(void);
    void set1_ch4(void);
    void set0_ch3(void);
    void set0_ch4(void);
    void service_reset(void);
    void service_power(void);
    void about(void);
    void about2(void);
    void showHide(QSystemTrayIcon::ActivationReason);
    void changeEvent(QEvent* e);
    void set_autostart(void);
    void set_pause(void);
    void set_resume(void);
    void save_ping_mode_state(void);
    void save_ping_mode_addr(void);
    void clear_led(void);


private:
    Ui::MainWindow *ui;
    SerialThread ser;
    QSystemTrayIcon *trIcon;
    void logger(const char* msg);
    void send_cmd(QString s);
    void sendSettings(void);
    void Draw(int i);


};

#endif // MAINWINDOW_H
