#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QBasicTimer>
#include <QDebug>
#include <QDateTime>
#include <QMessageBox>
#include <QProcess>
#include <QPixmap>
#include <QPainter>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    main_settings = new QSettings("Open Dev.", "USB WatchDog Monitor");

    trIcon = new QSystemTrayIcon();
    trIcon->setIcon(QIcon(":/icons/icon.png"));
    trIcon->show();

    timer = new QTimer;
    loadSettings();

    QObject::connect(ui->comboBox, SIGNAL(currentIndexChanged(QString)), this, SLOT(saveSettingsPort(QString)));
    QObject::connect(ui->comboBox, SIGNAL(currentIndexChanged(QString)), this, SLOT(timer_start()));

    QObject::connect(ui->horizontalSlider, SIGNAL(valueChanged(int)), this, SLOT(saveSettingsTime(int)));
    QObject::connect(ui->horizontalSlider_2, SIGNAL(valueChanged(int)), this, SLOT(saveSettingsPingTimeOut(int)));
    QObject::connect(ui->pushButton, SIGNAL(clicked()), this, SLOT(scanPorts()));
    QObject::connect(ui->actionReset, SIGNAL(triggered()), this, SLOT(reset_ch3()));
    QObject::connect(ui->actionReset_2, SIGNAL(triggered()), this, SLOT(reset_ch4()));
    QObject::connect(ui->actionPower, SIGNAL(triggered()), this, SLOT(power_ch3()));
    QObject::connect(ui->actionPower_2, SIGNAL(triggered()), this, SLOT(power_ch4()));
    QObject::connect(ui->actionSet_0, SIGNAL(triggered()), this, SLOT(set0_ch3()));
    QObject::connect(ui->actionSet_1, SIGNAL(triggered()), this, SLOT(set1_ch3()));
    QObject::connect(ui->actionSet_2, SIGNAL(triggered()), this, SLOT(set1_ch4()));
    QObject::connect(ui->actionSet_3, SIGNAL(triggered()), this, SLOT(set0_ch4()));

    QObject::connect(ui->actionReset_3, SIGNAL(triggered()), this, SLOT(service_reset()));
    QObject::connect(ui->actionPower_3, SIGNAL(triggered()), this, SLOT(service_power()));
    QObject::connect(ui->actionAbout, SIGNAL(triggered()), this, SLOT(about()));
    QObject::connect(ui->actionAbout_2, SIGNAL(triggered()), this, SLOT(about2()));

    QObject::connect(&ser, SIGNAL(response(QString)), this, SLOT(ser_read(QString)));
    QObject::connect(&ser, SIGNAL(error(QString)), this, SLOT(ser_error(QString)));
    QObject::connect(&ser, SIGNAL(timeout(QString)), this, SLOT(ser_error(QString)));

    QObject::connect(trIcon,SIGNAL(activated(QSystemTrayIcon::ActivationReason)),this,SLOT(showHide(QSystemTrayIcon::ActivationReason)));

    QObject::connect(ui->actionPause_timer, SIGNAL(triggered()), this, SLOT(set_pause()));
    QObject::connect(ui->actionResume_timer, SIGNAL(triggered()), this, SLOT(set_resume()));
    QObject::connect(ui->actionPing_mode, SIGNAL(triggered()), this, SLOT(save_ping_mode_state()));
    QObject::connect(ui->lineEdit, SIGNAL(editingFinished()), this, SLOT(save_ping_mode_addr()));

    QObject::connect(timer,SIGNAL(timeout()), this, SLOT(timer_int()));

    main_settings =  new QSettings("Open Dev.", "USB WatchDog Monitor");
#ifdef Q_OS_WIN
    win_settings = new QSettings("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run", QSettings::NativeFormat);
    ui->actionAutostart->setVisible(true);
    ui->actionAutostart->setEnabled(true);
    QObject::connect(ui->actionAutostart, SIGNAL(triggered()), this, SLOT(set_autostart()));
    ui->actionAutostart->setChecked(win_settings->contains("USB WatchDog Monitor"));
    ping_param = new QString("-n 1 ");
    ping_wait_param = new QString("-w ");
#else
    ping_param = new QString("-c 1 ");
    ping_wait_param = new QString("-i ");
#endif
    Draw(0);
}

void MainWindow::Draw(int i)
{
    QPixmap pixmap(10,10);
    pixmap.fill(QColor("transparent"));
    QPainter painter(&pixmap);
    if (i)
    {
        painter.setBrush(QBrush(Qt::green));
    }
    else
    {
        painter.setBrush(QBrush(Qt::gray));
    }
     painter.drawRect(1, 1, 10, 10);
    ui->label_4->setPixmap(pixmap);
}

void MainWindow::clear_led(void)
{
    Draw(0);
}

void MainWindow::send_cmd(QString s)
{
    ser.transaction(ui->comboBox->currentText(), 50, s);
}

void MainWindow::service_reset(void)
{
    send_cmd("~T1");
}

void MainWindow::service_power(void)
{
    send_cmd("~T2");
}

void MainWindow::about(void)
{
    send_cmd("~I");
}

void MainWindow::reset_ch3(void)
{
    send_cmd("~S3");
    QTimer::singleShot(200, this, SLOT(set0_ch3()));
}

void MainWindow::reset_ch4(void)
{
    send_cmd("~S4");
    QTimer::singleShot(200, this, SLOT(set0_ch4()));
}

void MainWindow::power_ch3(void)
{
    send_cmd("~S3");
    QTimer::singleShot(5000, this, SLOT(set0_ch3()));
}

void MainWindow::power_ch4(void)
{
    send_cmd("~S4");
    QTimer::singleShot(5000, this, SLOT(set0_ch4()));
}

void MainWindow::set1_ch3(void)
{
   send_cmd("~S3");
}

void MainWindow::set0_ch3(void)
{
   send_cmd("~R3");
}

void MainWindow::set1_ch4(void)
{
   send_cmd("~S4");
}

void MainWindow::set0_ch4(void)
{
   send_cmd("~R4");
}

void MainWindow::set_pause(void)
{
    send_cmd("~P1");
}

void MainWindow::set_resume(void)
{
    send_cmd("~P0");
}

void MainWindow::ser_read(const QString &s)
{
    QString c;
    static unsigned int state = 0;
    //qDebug() << s;
    for (int i = 0; i < s.size(); ++i)
    {
        c = s.at(i);
        if (state == 0) {state = (c == "~")? 1 : 0;}
        else
        {
            if (c == "A")
            {
                        //QDateTime local(QDateTime::currentDateTime());
                        //ui->statusBar->showMessage("Device response: " + local.toString("hh:mm:ss dd.MM.yy"), 1000);
                        Draw(1);
                        QTimer::singleShot(300, this, SLOT(clear_led()));
            } else
            if (c == "I")
            {
                if (s.size()>i+16)
                {
                    QString msg = "Device fw version: " + s.mid(i+1, i+17);
                    QMessageBox::information(0, "About", msg);
                    i += 16;
                }
            }
           state = 0;
        }
    }
}

void MainWindow::ser_error(const QString &s)
{
    ui->statusBar->showMessage(s, 500);
    ser.transaction("", 0, "");  //reopen port //todo: fixit
    if (!this->isVisible())
    {
        //trIcon->showMessage("Warning", s, QSystemTrayIcon::Information, 900);
    }
}

void MainWindow::about2()
{
    QString msg = "WDT Monitor v2.1\r\nOpen Development\r\nhttp://open-dev.ru";
    QMessageBox::information(0, "About", msg);
}

void MainWindow::timer_start()
{
    //ToDo: add 3 sec delay
    if(timer->isActive()){timer->stop();}
    sendSettings();
    timer->start(3000); //every 3 sec
}

void MainWindow::timer_int()
{
    if (ui->actionPing_mode->isChecked())
    {
        int exitCode = QProcess::execute("ping " + *ping_param + *ping_wait_param + QString::number(ui->horizontalSlider_2->value()) + " " + ui->lineEdit->text());

        if (exitCode==0) {
            qDebug() << "it's alive";
            send_cmd("~U");
        } else {
            qDebug() << "it's dead";
        }
    }
    else
    {
        send_cmd("~U");
    }
}

void MainWindow::scanPorts()
{
    serialPort = new QSerialPort(this);
    ui->comboBox->clear();
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
#ifdef Q_OS_WIN
        ui->comboBox->addItem(info.portName());
#else
        ui->comboBox->addItem(info.systemLocation());
#endif
    }
    saveSettingsPort(ui->comboBox->currentText());
    if (serialPort) {delete serialPort;}
}

void MainWindow::loadSettings(void)
{
    if (main_settings->contains("Port"))
    {
        ui->comboBox->addItem(main_settings->value("Port").toString());
        timer_start();
    }
    else
    {
       scanPorts();
    }

    if (main_settings->contains("Time"))
    {
        QString time = main_settings->value("Time").toString();
        ui->horizontalSlider->setValue(time.toInt());
        ui->label->setText(time);
        sendSettings();
    }
    else
    {
        ui->horizontalSlider->setValue(5);
        ui->label->setText("5");
        sendSettings();
    }

    if (main_settings->contains("Hidden") && main_settings->value("Hidden").toBool())
    {
         QTimer::singleShot(10, this, SLOT(hide()));
    }

    ui->actionPing_mode->setChecked(main_settings->contains("Ping_mode") && main_settings->value("Ping_mode").toBool());

    ui->tab_2->setEnabled(ui->actionPing_mode->isChecked());
    ui->lineEdit->setText(main_settings->value("Ping_mode_Addr").toString());
    if (main_settings->contains("PingTimeOut"))
    {
        QString PingTimeOut = main_settings->value("PingTimeOut").toString();
        ui->horizontalSlider_2->setValue(PingTimeOut.toInt());
        ui->label_6->setText(PingTimeOut);
    }
    else
    {
        ui->horizontalSlider_2->setValue(200);
        ui->label_6->setText("200");
    }
}

void MainWindow::saveSettingsPort(QString port)
{
    main_settings->setValue("Port", port);
    sendSettings();
}

void MainWindow::saveSettingsTime(int time)
{
    main_settings->setValue("Time", time);
    sendSettings();
}

void MainWindow::saveSettingsPingTimeOut(int time)
{
    main_settings->setValue("PingTimeOut", time);
}

void MainWindow::set_autostart(void)  // windows only
{
    if (ui->actionAutostart->isChecked())
    {
        QString value = QCoreApplication::applicationFilePath(); //get absolute path of running exe
        value.replace("/","\\");
        win_settings->setValue("USB WatchDog Monitor", value);
    }
    else
    {
        win_settings->remove("USB WatchDog Monitor");
    }
}

void MainWindow::sendSettings(void)
{
    QString data = QString("~W") + QString::number(ui->horizontalSlider->value());
    send_cmd(data);
}

void MainWindow::save_ping_mode_state(void)
{
    main_settings->setValue("Ping_mode", ui->actionPing_mode->isChecked());
    ui->tab_2->setEnabled(ui->actionPing_mode->isChecked());
}

void MainWindow::save_ping_mode_addr(void)
{
     main_settings->setValue("Ping_mode_Addr", ui->lineEdit->text());
}

void MainWindow::logger(const char* msg)
{
    QFile file;
    file.open(stderr, QIODevice::WriteOnly);
    file.write(msg, qstrlen(msg));        // write to stderr
    file.close();
}

void MainWindow::showHide(QSystemTrayIcon::ActivationReason r) {
    if (r==QSystemTrayIcon::Trigger)
    {
        if (!this->isVisible())
        {
            this->showNormal();
            //main_settings->setValue("Hidden", 0);
        }
        else
        {
            this->hide();
            //main_settings->setValue("Hidden", 1);
        }
        main_settings->setValue("Hidden", int(this->isVisible()));
    }
}

void MainWindow::changeEvent(QEvent* e)
{
    switch (e->type())
    {
        case QEvent::LanguageChange:
            this->ui->retranslateUi(this);
            break;
        case QEvent::WindowStateChange:
            {
                if (this->windowState() & Qt::WindowMinimized)
               {
                      QTimer::singleShot(10, this, SLOT(hide()));
                      main_settings->setValue("Hidden", 1);
               }

                break;
            }
        default:
            break;
    }

    QMainWindow::changeEvent(e);
}

MainWindow::~MainWindow()
{
    if(timer->isActive()){timer->stop();}
    if (timer) {delete timer;}
    if (trIcon) {delete trIcon;}
    //if (serialPort) {delete serialPort;}
    //if (main_settings) {delete main_settings;}
    //if (win_settings) {delete win_settings;}
    //if (ping_param) {delete ping_param;}
    delete ui;
}
