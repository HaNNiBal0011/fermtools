//---------------------------------------------------------------------------

#include <vcl.h>
#include <windows.h>
#pragma hdrstop

#include "wdt.h"
#include <IniFiles.hpp>
#include <stdio.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "Comm"
#pragma link "trayicon"
#pragma resource "*.dfm"
TForm1 *Form1;
TIniFile *Ini = new TIniFile(ExtractFilePath(ParamStr(0)) + "Settings.ini");

//---------------------------------------------------------------------------
void TForm1::Logging(String s)
{
 FILE * pFile = fopen ("log.txt","at+");
 fputs(s.c_str(),pFile);
 fclose (pFile);
}

void TForm1::Show(String s)
{
   ListBox1->Items->Add(s);
   ListBox1->TopIndex = ListBox1->Items->Count - 1;
}



//--------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
unsigned int TForm1::COM_Scan(int num)
{
int dev_count = 0;
TRegistry *reg = new TRegistry();
reg->RootKey = HKEY_LOCAL_MACHINE;
reg->OpenKey("HARDWARE\\DEVICEMAP\\SERIALCOMM", true);
ComboBox1->Items->Clear();
for(int i = 0; i < num; i++)
{
       if (reg->ValueExists("\\Device\\Silabser" + IntToStr(i)))
       {
               dev_count++;
               ComboBox1->Items->Add(reg->ReadString("\\Device\\Silabser" + IntToStr(i)));
       }
}

reg->CloseKey();
delete reg;
return(dev_count);
}

//---------------------------------------------------------------------------
const MAX_BUFSIZE = 256;
unsigned int Decode(char c,  unsigned char buf[])
{
 static unsigned int ptr = 0;
 static unsigned int len = 0;
 static unsigned int mode = 0;

 if (c == '~') //ToDo: clean
 {
 	mode = 1;
 	return 0;
 }

 if (mode == 1)
 {
        buf[ptr++] = c;
 }

 if (ptr > (MAX_BUFSIZE+1))
 {
 	mode = 0;
 	ptr = 0;
 	return 0;
 }

 if (c == '|')
 {
 	mode = 0;
 	len = ptr-1;
 	ptr = 0;
 	return len;
 }
return 0;

}

//---------------------------------------------------------------------------
char buf[100];
void __fastcall TForm1::Comm1RxChar(TObject *Sender, DWORD Count)
{
String rs;
unsigned int i, c, b, Bytes, len;

char rb[100], ts[3], cmd;
Bytes = Comm1->Read(rb, Count);

for (unsigned int i=0; i<Bytes; i++)
{
  len = Decode(rb[i], buf);
  if (len) //pkt present
  {
   switch (buf[0])
   {
     case 'L':
             if (len != 3) {break;}
             if (buf[1] == 'G')
             {
                Shape1->Brush->Color = (buf[2] == '1')? clLime: clGray;
             }
             if (buf[1] == 'R')
             {
                Shape2->Brush->Color = (buf[2] == '1')? clRed: clGray;
             }
             break;
      case 'I':
           ShowMessage("FirmWare: " + AnsiString(&buf[1]));
           break;

  }
  }
}

//if(Bytes > 0)
//{ rb[Bytes] = 0;
//for(i = 0, rs = ""; i < Bytes; i++)
//    { c = rb[i];
//      if((b = (c & 15) + '0') > '9') b += 7;
//      ts[1] = b;
//      if((b = (c / 16) + '0') > '9') b += 7;
//      ts[0] = b;
//      ts[2] = 0;
//      rs = rs + (char*)ts + " ";
//    }
//}
//ListBox1->Items->Add(rs);
}
//---------------------------------------------------------------------------

void TForm1::Send(unsigned char buf[], unsigned char size)
{
  if(Comm1->Enabled())
  {
        Comm1->Write(buf, size);
  } else
  {
        String log = DateTimeToStr(Now()) + " Writing failed";
        Show(log);
        Logging(log+"\n");
  }

}

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
    unsigned char msg[] = "~U|";
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

void __fastcall TForm1::menu21Click(TObject *Sender)
{
  Form1->Visible = true;
  TrayIcon1->Restore();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Quit1Click(TObject *Sender)
{
        Form1->Close();
}

//---------------------------------------------------------------------------
void TForm1::COM_Start(String port, String time)
{
 String log;
 Comm1->DeviceName = port;
 Comm1->Open();
 StatusBar1->Panels->Items[1]->Text = Comm1->DeviceName;
 if(Comm1->Enabled())
 {
               Comm1->PurgeIn();
               Comm1->PurgeOut();
               StatusBar1->Panels->Items[3]->Text = "OK";
               unsigned char msg[] ={'~', 'W',  time.c_str()[0]  , '|'};
               Send(msg, sizeof(msg));
               StatusBar1->Panels->Items[5]->Text = time;
               log = DateTimeToStr(Now()) + " Port opened";
               Show(log);
               Timer1->Enabled = True;
               Button1->Enabled = False;
               Button2->Enabled = True;
 }
  else
 {
               StatusBar1->Panels->Items[3]->Text = "ERROR";
               log =DateTimeToStr(Now()) + " Port open fail";
               Show(log);
               Button1->Enabled = True;
               Button2->Enabled = False;

 }
Logging(log+"\n");
}

void __fastcall TForm1::FormCreate(TObject *Sender)
{
        Application->ShowMainForm = False;
        HMENU MenuHandle = GetSystemMenu(Handle, false);
        if(MenuHandle)
        {
        DeleteMenu(MenuHandle, SC_CLOSE, MF_BYCOMMAND);
        }

        AnsiString sport =  Ini->ReadString("Settings","Port","");
        COM_Scan(5);
        ComboBox1->Text = sport;

        AnsiString stime = Ini->ReadString("Settings","Time","1");
        TrackBar1->Position = StrToInt(stime);

        String log = DateTimeToStr(Now())+ " Application started.  " +  + "Port: " + sport + "  Time: " + stime + "\n";
        Logging(log);
        COM_Start(sport, IntToStr(TrackBar1->Position));
}

//---------------------------------------------------------------------------
void __fastcall TForm1::N31Click(TObject *Sender)
{
    unsigned char msg[] = "~S3|";
    Send(msg, sizeof(msg));
    Sleep(5000);
    msg[1] = 'R';
    Send(msg, sizeof(msg));

}
//---------------------------------------------------------------------------

void __fastcall TForm1::N41Click(TObject *Sender)
{
    unsigned char msg[] = "~S4|";
    Send(msg, sizeof(msg));
    Sleep(5000);
    msg[1] = 'R';
    Send(msg, sizeof(msg));
}

//---------------------------------------------------------------------------
void __fastcall TForm1::N33Click(TObject *Sender)
{
    unsigned char msg[] = "~S3|";
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::N43Click(TObject *Sender)
{
    unsigned char msg[] = "~S4|";
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::N34Click(TObject *Sender)
{
    unsigned char msg[] = "~R3|";
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N44Click(TObject *Sender)
{
    unsigned char msg[] = "~R4|";
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Channel11Click(TObject *Sender)
{
    unsigned char msg[] = "~T1|";
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Channel21Click(TObject *Sender)
{
    unsigned char msg[] = "~T2|";
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
  String log = DateTimeToStr(Now())+ " Application closed\n";
  Logging(log);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)
{
  COM_Scan(5);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TrackBar1Change(TObject *Sender)
{
    Label4->Caption= IntToStr(TrackBar1->Position) + " min";
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button2Click(TObject *Sender)
{
   Timer1->Enabled = False;
   Button1->Enabled = True;
   Button2->Enabled = False;
   Comm1->Close();
   Show(DateTimeToStr(Now()) + " Port closed");
   Logging(DateTimeToStr(Now()) + " Port closed manually\n");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button4Click(TObject *Sender)
{
  String time = IntToStr(TrackBar1->Position);
  Ini->WriteString("Settings", "Port", ComboBox1->Text);
  Ini->WriteString("Settings", "Time", time);
  Show(DateTimeToStr(Now()) + " Saved");
  String log = DateTimeToStr(Now()) + " New settings: " + ComboBox1->Text +"," + IntToStr(TrackBar1->Position) + "min saved\n";
  Logging(log);
  if(Comm1->Enabled())
  {
   unsigned char msg[] ={'~', 'W',  time.c_str()[0]  , '|'};
   Send(msg, sizeof(msg));
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
  COM_Start(ComboBox1->Text, IntToStr(TrackBar1->Position));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Channel31Click(TObject *Sender)
{
    unsigned char msg[] = "~S3|";
    Send(msg, sizeof(msg));
    Sleep(200);
    msg[1] = 'R';
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Ch41Click(TObject *Sender)
{
    unsigned char msg[] = "~S4|";
    Send(msg, sizeof(msg));
    Sleep(200);
    msg[1] = 'R';
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FWInfo1Click(TObject *Sender)
{
    unsigned char msg[] = "~I|";
    Send(msg, sizeof(msg));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TrayIcon1Click(TObject *Sender)
{
  Form1->Visible = true;
  TrayIcon1->Restore();

}
//---------------------------------------------------------------------------

