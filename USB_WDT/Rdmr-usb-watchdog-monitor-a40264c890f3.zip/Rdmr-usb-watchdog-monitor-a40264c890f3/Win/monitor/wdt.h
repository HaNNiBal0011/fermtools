//---------------------------------------------------------------------------

#ifndef wdtH
#define wdtH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Comm.h"
#include "Registry.hpp" // ��� ������ � ��������
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include "trayicon.h"
#include <Menus.hpp>
#include <ImgList.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TComm *Comm1;
        TTimer *Timer1;
        TTrayIcon *TrayIcon1;
        TPopupMenu *PopupMenu1;
        TMenuItem *menu11;
        TMenuItem *menu21;
        TMenuItem *Quit1;
        TMenuItem *Manualset11;
        TMenuItem *N33;
        TMenuItem *N43;
        TMenuItem *N34;
        TMenuItem *N44;
        TImageList *ImageList1;
        TMenuItem *Manualreset1;
        TMenuItem *N31;
        TMenuItem *N41;
        TMenuItem *Test1;
        TMenuItem *Channel11;
        TMenuItem *Channel21;
        TStatusBar *StatusBar1;
        TPanel *Panel1;
        TLabel *Label2;
        TLabel *Label3;
        TListBox *ListBox1;
        TComboBox *ComboBox1;
        TButton *Button1;
        TButton *Button2;
        TShape *Shape1;
        TShape *Shape2;
        TTrackBar *TrackBar1;
        TLabel *Label4;
        TButton *Button4;
        TButton *Button3;
        TMenuItem *ManualReset2;
        TMenuItem *Channel31;
        TMenuItem *Ch41;
        TMenuItem *FWInfo1;
        void __fastcall Comm1RxChar(TObject *Sender, DWORD Count);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall N31Click(TObject *Sender);
        void __fastcall N41Click(TObject *Sender);
        void __fastcall menu21Click(TObject *Sender);
        void __fastcall Quit1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall N33Click(TObject *Sender);
        void __fastcall N43Click(TObject *Sender);
        void __fastcall N34Click(TObject *Sender);
        void __fastcall N44Click(TObject *Sender);
        void __fastcall Channel11Click(TObject *Sender);
        void __fastcall Channel21Click(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall TrackBar1Change(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Channel31Click(TObject *Sender);
        void __fastcall Ch41Click(TObject *Sender);
        void __fastcall FWInfo1Click(TObject *Sender);
        void __fastcall TrayIcon1Click(TObject *Sender);

private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
        unsigned int COM_Scan(int num);
        void COM_Start(String port, String time);
        void Show(String s);
        void Logging(String s);
        void Send(unsigned char buf[], unsigned char size);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
